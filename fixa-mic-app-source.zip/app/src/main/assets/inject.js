(() => {
  if (window.__fixaMic) return;
  window.__fixaMic = true;

  const FREQS = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
  const PRESETS = {
    Flat:   [0,0,0,0,0,0,0,0,0,0],
    Studio: [-8,-3,1,0,-1,1,2,3,2,1],
    Bass:   [-6,3,5,3,0,0,0,0,0,0],
    Clear:  [-12,-6,-2,0,0,2,4,4,2,0],
    Phone:  [-24,-24,-12,-3,2,4,3,-6,-24,-24]
  };
  const S = { bypass: false, gain: 1, vol: 1, gate: -60, echoMix: 0, echoDelay: 0.3, sbVol: 1, eq: PRESETS.Studio.slice() };

  let ctx, dest, nodes = {}, sbSource = null, sbBuffer = null;

  function build(rawStream) {
    ctx = new (window.AudioContext || window.webkitAudioContext)({ latencyHint: 'interactive' });
    dest = ctx.createMediaStreamDestination();
    const src = ctx.createMediaStreamSource(rawStream);
    const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 80;
    const pre = ctx.createGain();
    const eq = FREQS.map((f, i) => {
      const b = ctx.createBiquadFilter(); b.type = 'peaking'; b.frequency.value = f; b.Q.value = 1.1; b.gain.value = S.eq[i]; return b;
    });
    const gate = ctx.createGain();
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -18; comp.knee.value = 12; comp.ratio.value = 4; comp.attack.value = 0.005; comp.release.value = 0.15;
    const limiter = ctx.createDynamicsCompressor();
    limiter.threshold.value = -2; limiter.knee.value = 0; limiter.ratio.value = 20; limiter.attack.value = 0.001; limiter.release.value = 0.05;
    const master = ctx.createGain();
    const dry = ctx.createGain();
    const delay = ctx.createDelay(1.5); const fb = ctx.createGain(); fb.gain.value = 0.35; const wet = ctx.createGain();
    const analyser = ctx.createAnalyser(); analyser.fftSize = 1024;
    const sbGain = ctx.createGain();

    let n = src; [hp, pre, ...eq, gate, comp, limiter].forEach(x => { n.connect(x); n = x; });
    limiter.connect(analyser);
    limiter.connect(dry); dry.connect(master);
    limiter.connect(delay); delay.connect(fb); fb.connect(delay); delay.connect(wet); wet.connect(master);
    master.connect(dest);
    sbGain.connect(dest);

    nodes = { pre, eq, gate, master, delay, wet, sbGain, analyser };
    const buf = new Float32Array(analyser.fftSize);
    setInterval(() => {
      analyser.getFloatTimeDomainData(buf);
      let s = 0; for (const v of buf) s += v * v;
      const db = 20 * Math.log10(Math.sqrt(s / buf.length) + 1e-9);
      gate.gain.setTargetAtTime(db < S.gate ? 0 : 1, ctx.currentTime, 0.03);
    }, 25);
    apply();
    return dest.stream;
  }

  function apply() {
    if (!ctx) return;
    nodes.pre.gain.value = S.gain;
    nodes.master.gain.value = S.vol;
    nodes.delay.delayTime.value = S.echoDelay;
    nodes.wet.gain.value = S.echoMix;
    nodes.sbGain.gain.value = S.sbVol;
    nodes.eq.forEach((b, i) => b.gain.value = S.eq[i]);
  }

  const md = navigator.mediaDevices;
  const origGUM = md.getUserMedia.bind(md);
  md.getUserMedia = async (constraints) => {
    if (!constraints || !constraints.audio) return origGUM(constraints);
    const audio = typeof constraints.audio === 'object' ? { ...constraints.audio } : {};
    Object.assign(audio, { autoGainControl: false, noiseSuppression: false, echoCancellation: true });
    const raw = await origGUM({ ...constraints, audio });
    if (S.bypass) return raw;
    const processed = build(new MediaStream(raw.getAudioTracks()));
    if (ctx.state === 'suspended') ctx.resume();
    const out = new MediaStream();
    processed.getAudioTracks().forEach(t => out.addTrack(t));
    raw.getVideoTracks().forEach(t => out.addTrack(t));
    // stopping the processed track stops the real mic
    out.getAudioTracks().forEach(t => { const st = t.stop.bind(t); t.stop = () => { st(); raw.getTracks().forEach(r => r.stop()); }; });
    return out;
  };

  async function loadFile(file) {
    if (!ctx) { alert('Start a call or voice message first, then load audio.'); return; }
    sbBuffer = await ctx.decodeAudioData(await file.arrayBuffer());
  }
  function play() {
    if (!ctx || !sbBuffer) return;
    stop();
    sbSource = ctx.createBufferSource(); sbSource.buffer = sbBuffer;
    sbSource.connect(nodes.sbGain); sbSource.start();
  }
  function stop() { try { sbSource && sbSource.stop(); } catch (e) {} sbSource = null; }

  // ---------- UI ----------
  function ui() {
    const btn = document.createElement('div');
    btn.textContent = '🎙';
    btn.style.cssText = 'position:fixed;right:12px;bottom:90px;z-index:999999;width:46px;height:46px;border-radius:50%;background:#12b886;color:#fff;font-size:22px;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px #0008';
    const p = document.createElement('div');
    p.style.cssText = 'position:fixed;right:12px;bottom:145px;z-index:999999;width:290px;max-height:70vh;overflow:auto;background:#111;color:#eee;font:13px sans-serif;border-radius:12px;padding:12px;display:none;box-shadow:0 4px 16px #000a';
    const row = (label, min, max, step, val, fmt, cb) => {
      const d = document.createElement('div'); d.style.margin = '8px 0';
      const l = document.createElement('div'); const r = document.createElement('input');
      r.type = 'range'; r.min = min; r.max = max; r.step = step; r.value = val; r.style.width = '100%';
      const upd = () => l.textContent = label + ': ' + fmt(+r.value);
      r.oninput = () => { cb(+r.value); upd(); apply(); }; upd();
      d.append(l, r); return d;
    };
    const b = (t, f) => { const x = document.createElement('button'); x.textContent = t; x.onclick = f; x.style.cssText = 'margin:3px;padding:6px 10px;border:0;border-radius:8px;background:#2b2b2b;color:#fff'; return x; };

    const title = document.createElement('b'); title.textContent = 'FIXA MIC APP';
    const byp = b('Bypass: OFF', () => { S.bypass = !S.bypass; byp.textContent = 'Bypass: ' + (S.bypass ? 'ON' : 'OFF'); });
    const note = document.createElement('div'); note.style.cssText = 'color:#999;font-size:11px'; note.textContent = 'Bypass applies to the next call / voice message.';
    p.append(title, document.createElement('br'), byp, note);
    p.append(row('Mic gain', 0, 4, 0.05, 1, v => Math.round(v * 100) + '%', v => S.gain = v));
    p.append(row('Master volume', 0, 2, 0.05, 1, v => Math.round(v * 100) + '%', v => S.vol = v));
    p.append(row('Noise gate', -90, -30, 1, -60, v => v + ' dB', v => S.gate = v));
    p.append(row('Echo mix', 0, 0.6, 0.02, 0, v => Math.round(v * 100) + '%', v => S.echoMix = v));
    p.append(row('Echo delay', 0.1, 0.8, 0.02, 0.3, v => Math.round(v * 1000) + ' ms', v => S.echoDelay = v));

    const eqTitle = document.createElement('div'); eqTitle.textContent = 'EQ presets'; eqTitle.style.marginTop = '8px';
    p.append(eqTitle);
    const sliders = [];
    Object.keys(PRESETS).forEach(k => p.append(b(k, () => { S.eq = PRESETS[k].slice(); sliders.forEach((s, i) => s.value = S.eq[i]); apply(); })));
    const eqBox = document.createElement('div'); eqBox.style.cssText = 'display:flex;gap:2px;margin-top:6px';
    FREQS.forEach((f, i) => {
      const w = document.createElement('div'); w.style.cssText = 'flex:1;text-align:center;font-size:9px';
      const s = document.createElement('input'); s.type = 'range'; s.min = -12; s.max = 12; s.step = 1; s.value = S.eq[i];
      s.style.cssText = 'writing-mode:vertical-lr;direction:rtl;width:18px;height:80px';
      s.oninput = () => { S.eq[i] = +s.value; apply(); };
      sliders.push(s); w.append(s, document.createTextNode(f >= 1000 ? f / 1000 + 'k' : f)); eqBox.append(w);
    });
    p.append(eqBox);

    const sbT = document.createElement('div'); sbT.textContent = 'Soundboard (plays into the call)'; sbT.style.marginTop = '10px';
    const file = document.createElement('input'); file.type = 'file'; file.accept = 'audio/*'; file.onchange = () => file.files[0] && loadFile(file.files[0]);
    p.append(sbT, file, b('▶ Play', play), b('■ Stop', stop));
    p.append(row('Soundboard volume', 0, 3, 0.05, 1, v => Math.round(v * 100) + '%', v => S.sbVol = v));

    btn.onclick = () => p.style.display = p.style.display === 'none' ? 'block' : 'none';
    document.body.append(p, btn);
  }
  const wait = setInterval(() => { if (document.body) { clearInterval(wait); ui(); } }, 200);
})();
