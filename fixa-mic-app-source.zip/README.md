# FIXA MIC APP
Android app (WebView) that opens WhatsApp Web with the FIXA mic engine injected.
Works with WhatsApp and WhatsApp Business accounts (link as a device via QR / phone number).
Edit app/src/main/assets/inject.js to change the mic engine. Push to GitHub -> Actions builds the APK.
